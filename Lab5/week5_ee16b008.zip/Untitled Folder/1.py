# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 14:51:09 2018

@author: Shripad Deshmukh
"""
import numpy as np
import scipy as sp
from pylab import *
import mpl_toolkits.mplot3d.axes3d as p3 

Nx=25
Ny=25
radius=0.35
Niter=1500

phi = np.zeros((Ny,Nx))

y=linspace(-0.5,0.5,Ny)
x=linspace(-0.5,0.5,Nx)

Y,X=meshgrid(y,x)

ii=np.where(X*X+Y*Y<=radius**2)

phi[ii]=1.0

con=contour(Y,-X,phi,inline=True)
clabel(con,inline=1,fontsize=10,loc='best')
title('The initial potential picture')
show()

errors=np.zeros(Niter)
for k in range (Niter) :
    #save copy of phi
    oldphi=phi.copy()
    
    #update phi array
    phi[1:-1,1:-1]=0.25*(phi[1:-1,0:-2]+ phi[1:-1,2:]+ phi[0:-2,1:-1]+ phi[2:,1:-1])
    
   
    	#side boundaries  
    phi[1:-1,0]=phi[1:-1,1]
    phi[1:-1,-1]=phi[1:-1,-2]
        #upper boundary
    phi[0,1:-1]=phi[1,1:-1]
        #lower boundary
    phi[-1,1:-1]=0.0
        #the circle in the middle
    phi[ii]=1.0
    	#finding the errors     
    errors[k]=(abs)(phi-oldphi).max() 


#plotting the errors, fit1 and fit2

	#errors
semilogy (arange(Niter),errors,'k')
title('The errors vs interation index')
xlabel('n')
ylabel('$log(error_{n})$')

	#fit1
mat1=np.zeros((Niter,2))
mat1[:,0]=1.0
mat1[:,1]=arange(Niter)

fit1=lstsq(mat1,log(errors))
print 'A=',exp(fit1[0][0]),'B=', -fit1[0][1]
semilogy (arange(Niter),exp(fit1[0][0]+fit1[0][1]*arange(Niter)),'r.')
	#fit2
fit2=lstsq(mat1[:][500:],log(errors[500:]))
print 'A=',exp(fit2[0][0]),'B=', -fit2[0][1]
semilogy (arange(Niter),exp(fit2[0][0]+fit2[0][1]*arange(Niter)),'b')

legend(('errors', 'fit1','fit2'))
title('the errors and fits plot')
show()

#plotting 3D plot of the potential 
fig1=figure(4)
ax=p3.Axes3D(fig1)
title('The 3-D surface plot of the potential')
surf = ax.plot_surface(Y, X, phi.T, rstride=1, cstride=1, cmap=cm.jet,linewidth=1)
show()

#contour plot of phi
con=contour(Y,-X,phi,inline=True)
clabel(con,inline=1,fontsize=10)
plot (Y[ii],X[ii],'ro')
title('potential contour')
show()

#current quiver plots
Jx=zeros((Ny,Nx))
Jy=zeros((Ny,Nx))
Jy[1:-1,1:-1]=-0.5*(phi[1:-1,0:-2]-phi[1:-1,2:])
Jx[1:-1,1:-1]=-0.5*(phi[0:-2,1:-1]-phi[2:,1:-1])
quiver(y,x,Jy[::-1,:],Jx[::-1,:])
plot (Y[ii],X[ii],'ro')
title('The vector plot of the current flow')
show()

#finding the heat generated
q=Jx**2+Jy**2 #note that the value of sigma is taken to be 1
con1=contour(y,-x,q,inline=True)
clabel(con1,inline=1,fontsize=10)
title('the rate of heat generation on the plate')
show()


