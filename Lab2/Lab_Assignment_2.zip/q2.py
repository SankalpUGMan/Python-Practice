from pylab import *

x = arange(0, 5.1, 0.1)
print(x)
